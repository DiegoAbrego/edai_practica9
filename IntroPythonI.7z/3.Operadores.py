#Para el exponente se  puede utilizar asterisco
print( 1 + 5 )
print( 6 * 3 )
print( 10 - 4 )
print( 100 / 50 )
print( 10 % 2 )
print( ((20 * 3) + (10 +1)) / 10 )
print( 2**2 )

print(False and True) #False

print (7 < 5)  #Falso

print (7 > 5) #Verdadero

print ((11 * 3)+2 == 36 - 1)  #Verdadero

print ((11 * 3)+2 >= 36)   #Falso

print ("curso" != "CuRsO") #Verdadero

input()
