#Inicializando variables
x = 10     #tipo entero
print(x)   #imprimir los valores de las variables

#comillas dobles o simples para crear una cadena
cadena = "Hola Mundo"    #varible de tipo cadena
print(cadena)

#Asigna un mismo valor a tres variables
x = y = z = 10
print(x,y,z)

#La función type() permite conocer el tipo de una variable
print(type(x))

print(type(cadena))

#Se pueden cambiar los valores de las variables y el tipo se cambia automáticamente
x = "Hola Mundo"
cadena = 10

print(type(x))

print(type(cadena))

SEGUNDOS_POR_DIA = 60 * 60 * 24
PI = 3.14

print(SEGUNDOS_POR_DIA, PI)

input()
